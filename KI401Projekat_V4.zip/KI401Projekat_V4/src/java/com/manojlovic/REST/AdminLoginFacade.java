/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.REST;

import com.manojlovic.entiteti.AdminLogin;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author manojlovic
 */
@Stateless
public class AdminLoginFacade extends AbstractFacade<AdminLogin> {

    @PersistenceContext(unitName = "KI401Projekat_V4PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AdminLoginFacade() {
        super(AdminLogin.class);
    }
    
}
