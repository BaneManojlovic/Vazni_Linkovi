/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpacontroller;

import com.manojlovic.jpa.Zaposleni;
import com.manojlovic.jpacontroller.exceptions.NonexistentEntityException;
import com.manojlovic.jpacontroller.exceptions.PreexistingEntityException;
import com.manojlovic.jpacontroller.exceptions.RollbackFailureException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class ZaposleniJpaController implements Serializable {

    public ZaposleniJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Zaposleni zaposleni) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            em.persist(zaposleni);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findZaposleni(zaposleni.getZaposleniBr()) != null) {
                throw new PreexistingEntityException("Zaposleni " + zaposleni + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Zaposleni zaposleni) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            zaposleni = em.merge(zaposleni);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = zaposleni.getZaposleniBr();
                if (findZaposleni(id) == null) {
                    throw new NonexistentEntityException("The zaposleni with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Zaposleni zaposleni;
            try {
                zaposleni = em.getReference(Zaposleni.class, id);
                zaposleni.getZaposleniBr();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The zaposleni with id " + id + " no longer exists.", enfe);
            }
            em.remove(zaposleni);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Zaposleni> findZaposleniEntities() {
        return findZaposleniEntities(true, -1, -1);
    }

    public List<Zaposleni> findZaposleniEntities(int maxResults, int firstResult) {
        return findZaposleniEntities(false, maxResults, firstResult);
    }

    private List<Zaposleni> findZaposleniEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Zaposleni.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Zaposleni findZaposleni(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Zaposleni.class, id);
        } finally {
            em.close();
        }
    }

    public int getZaposleniCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Zaposleni> rt = cq.from(Zaposleni.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
