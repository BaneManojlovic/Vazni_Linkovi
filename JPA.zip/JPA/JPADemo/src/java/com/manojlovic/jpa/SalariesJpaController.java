/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpa;

import com.manojlovic.jpa.exceptions.NonexistentEntityException;
import com.manojlovic.jpa.exceptions.PreexistingEntityException;
import com.manojlovic.jpa.exceptions.RollbackFailureException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class SalariesJpaController implements Serializable {

    public SalariesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Salaries salaries) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (salaries.getSalariesPK() == null) {
            salaries.setSalariesPK(new SalariesPK());
        }
        salaries.getSalariesPK().setEmpNo(salaries.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Employees employees = salaries.getEmployees();
            if (employees != null) {
                employees = em.getReference(employees.getClass(), employees.getEmpNo());
                salaries.setEmployees(employees);
            }
            em.persist(salaries);
            if (employees != null) {
                employees.getSalariesCollection().add(salaries);
                employees = em.merge(employees);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findSalaries(salaries.getSalariesPK()) != null) {
                throw new PreexistingEntityException("Salaries " + salaries + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Salaries salaries) throws NonexistentEntityException, RollbackFailureException, Exception {
        salaries.getSalariesPK().setEmpNo(salaries.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Salaries persistentSalaries = em.find(Salaries.class, salaries.getSalariesPK());
            Employees employeesOld = persistentSalaries.getEmployees();
            Employees employeesNew = salaries.getEmployees();
            if (employeesNew != null) {
                employeesNew = em.getReference(employeesNew.getClass(), employeesNew.getEmpNo());
                salaries.setEmployees(employeesNew);
            }
            salaries = em.merge(salaries);
            if (employeesOld != null && !employeesOld.equals(employeesNew)) {
                employeesOld.getSalariesCollection().remove(salaries);
                employeesOld = em.merge(employeesOld);
            }
            if (employeesNew != null && !employeesNew.equals(employeesOld)) {
                employeesNew.getSalariesCollection().add(salaries);
                employeesNew = em.merge(employeesNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                SalariesPK id = salaries.getSalariesPK();
                if (findSalaries(id) == null) {
                    throw new NonexistentEntityException("The salaries with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(SalariesPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Salaries salaries;
            try {
                salaries = em.getReference(Salaries.class, id);
                salaries.getSalariesPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The salaries with id " + id + " no longer exists.", enfe);
            }
            Employees employees = salaries.getEmployees();
            if (employees != null) {
                employees.getSalariesCollection().remove(salaries);
                employees = em.merge(employees);
            }
            em.remove(salaries);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Salaries> findSalariesEntities() {
        return findSalariesEntities(true, -1, -1);
    }

    public List<Salaries> findSalariesEntities(int maxResults, int firstResult) {
        return findSalariesEntities(false, maxResults, firstResult);
    }

    private List<Salaries> findSalariesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Salaries.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Salaries findSalaries(SalariesPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Salaries.class, id);
        } finally {
            em.close();
        }
    }

    public int getSalariesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Salaries> rt = cq.from(Salaries.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
