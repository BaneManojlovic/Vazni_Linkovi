/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpa;

import com.manojlovic.jpa.exceptions.NonexistentEntityException;
import com.manojlovic.jpa.exceptions.PreexistingEntityException;
import com.manojlovic.jpa.exceptions.RollbackFailureException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class DeptEmpJpaController implements Serializable {

    public DeptEmpJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DeptEmp deptEmp) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (deptEmp.getDeptEmpPK() == null) {
            deptEmp.setDeptEmpPK(new DeptEmpPK());
        }
        deptEmp.getDeptEmpPK().setDeptNo(deptEmp.getDepartments().getDeptNo());
        deptEmp.getDeptEmpPK().setEmpNo(deptEmp.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Employees employees = deptEmp.getEmployees();
            if (employees != null) {
                employees = em.getReference(employees.getClass(), employees.getEmpNo());
                deptEmp.setEmployees(employees);
            }
            Departments departments = deptEmp.getDepartments();
            if (departments != null) {
                departments = em.getReference(departments.getClass(), departments.getDeptNo());
                deptEmp.setDepartments(departments);
            }
            em.persist(deptEmp);
            if (employees != null) {
                employees.getDeptEmpCollection().add(deptEmp);
                employees = em.merge(employees);
            }
            if (departments != null) {
                departments.getDeptEmpCollection().add(deptEmp);
                departments = em.merge(departments);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDeptEmp(deptEmp.getDeptEmpPK()) != null) {
                throw new PreexistingEntityException("DeptEmp " + deptEmp + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DeptEmp deptEmp) throws NonexistentEntityException, RollbackFailureException, Exception {
        deptEmp.getDeptEmpPK().setDeptNo(deptEmp.getDepartments().getDeptNo());
        deptEmp.getDeptEmpPK().setEmpNo(deptEmp.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptEmp persistentDeptEmp = em.find(DeptEmp.class, deptEmp.getDeptEmpPK());
            Employees employeesOld = persistentDeptEmp.getEmployees();
            Employees employeesNew = deptEmp.getEmployees();
            Departments departmentsOld = persistentDeptEmp.getDepartments();
            Departments departmentsNew = deptEmp.getDepartments();
            if (employeesNew != null) {
                employeesNew = em.getReference(employeesNew.getClass(), employeesNew.getEmpNo());
                deptEmp.setEmployees(employeesNew);
            }
            if (departmentsNew != null) {
                departmentsNew = em.getReference(departmentsNew.getClass(), departmentsNew.getDeptNo());
                deptEmp.setDepartments(departmentsNew);
            }
            deptEmp = em.merge(deptEmp);
            if (employeesOld != null && !employeesOld.equals(employeesNew)) {
                employeesOld.getDeptEmpCollection().remove(deptEmp);
                employeesOld = em.merge(employeesOld);
            }
            if (employeesNew != null && !employeesNew.equals(employeesOld)) {
                employeesNew.getDeptEmpCollection().add(deptEmp);
                employeesNew = em.merge(employeesNew);
            }
            if (departmentsOld != null && !departmentsOld.equals(departmentsNew)) {
                departmentsOld.getDeptEmpCollection().remove(deptEmp);
                departmentsOld = em.merge(departmentsOld);
            }
            if (departmentsNew != null && !departmentsNew.equals(departmentsOld)) {
                departmentsNew.getDeptEmpCollection().add(deptEmp);
                departmentsNew = em.merge(departmentsNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                DeptEmpPK id = deptEmp.getDeptEmpPK();
                if (findDeptEmp(id) == null) {
                    throw new NonexistentEntityException("The deptEmp with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(DeptEmpPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptEmp deptEmp;
            try {
                deptEmp = em.getReference(DeptEmp.class, id);
                deptEmp.getDeptEmpPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The deptEmp with id " + id + " no longer exists.", enfe);
            }
            Employees employees = deptEmp.getEmployees();
            if (employees != null) {
                employees.getDeptEmpCollection().remove(deptEmp);
                employees = em.merge(employees);
            }
            Departments departments = deptEmp.getDepartments();
            if (departments != null) {
                departments.getDeptEmpCollection().remove(deptEmp);
                departments = em.merge(departments);
            }
            em.remove(deptEmp);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DeptEmp> findDeptEmpEntities() {
        return findDeptEmpEntities(true, -1, -1);
    }

    public List<DeptEmp> findDeptEmpEntities(int maxResults, int firstResult) {
        return findDeptEmpEntities(false, maxResults, firstResult);
    }

    private List<DeptEmp> findDeptEmpEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DeptEmp.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DeptEmp findDeptEmp(DeptEmpPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DeptEmp.class, id);
        } finally {
            em.close();
        }
    }

    public int getDeptEmpCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DeptEmp> rt = cq.from(DeptEmp.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
