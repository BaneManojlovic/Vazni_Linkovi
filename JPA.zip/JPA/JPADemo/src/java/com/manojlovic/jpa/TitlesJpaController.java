/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpa;

import com.manojlovic.jpa.exceptions.NonexistentEntityException;
import com.manojlovic.jpa.exceptions.PreexistingEntityException;
import com.manojlovic.jpa.exceptions.RollbackFailureException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class TitlesJpaController implements Serializable {

    public TitlesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Titles titles) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (titles.getTitlesPK() == null) {
            titles.setTitlesPK(new TitlesPK());
        }
        titles.getTitlesPK().setEmpNo(titles.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Employees employees = titles.getEmployees();
            if (employees != null) {
                employees = em.getReference(employees.getClass(), employees.getEmpNo());
                titles.setEmployees(employees);
            }
            em.persist(titles);
            if (employees != null) {
                employees.getTitlesCollection().add(titles);
                employees = em.merge(employees);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findTitles(titles.getTitlesPK()) != null) {
                throw new PreexistingEntityException("Titles " + titles + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Titles titles) throws NonexistentEntityException, RollbackFailureException, Exception {
        titles.getTitlesPK().setEmpNo(titles.getEmployees().getEmpNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Titles persistentTitles = em.find(Titles.class, titles.getTitlesPK());
            Employees employeesOld = persistentTitles.getEmployees();
            Employees employeesNew = titles.getEmployees();
            if (employeesNew != null) {
                employeesNew = em.getReference(employeesNew.getClass(), employeesNew.getEmpNo());
                titles.setEmployees(employeesNew);
            }
            titles = em.merge(titles);
            if (employeesOld != null && !employeesOld.equals(employeesNew)) {
                employeesOld.getTitlesCollection().remove(titles);
                employeesOld = em.merge(employeesOld);
            }
            if (employeesNew != null && !employeesNew.equals(employeesOld)) {
                employeesNew.getTitlesCollection().add(titles);
                employeesNew = em.merge(employeesNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                TitlesPK id = titles.getTitlesPK();
                if (findTitles(id) == null) {
                    throw new NonexistentEntityException("The titles with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(TitlesPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Titles titles;
            try {
                titles = em.getReference(Titles.class, id);
                titles.getTitlesPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The titles with id " + id + " no longer exists.", enfe);
            }
            Employees employees = titles.getEmployees();
            if (employees != null) {
                employees.getTitlesCollection().remove(titles);
                employees = em.merge(employees);
            }
            em.remove(titles);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Titles> findTitlesEntities() {
        return findTitlesEntities(true, -1, -1);
    }

    public List<Titles> findTitlesEntities(int maxResults, int firstResult) {
        return findTitlesEntities(false, maxResults, firstResult);
    }

    private List<Titles> findTitlesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Titles.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Titles findTitles(TitlesPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Titles.class, id);
        } finally {
            em.close();
        }
    }

    public int getTitlesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Titles> rt = cq.from(Titles.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
