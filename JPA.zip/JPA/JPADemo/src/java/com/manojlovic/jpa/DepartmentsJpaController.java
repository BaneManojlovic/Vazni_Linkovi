/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpa;

import com.manojlovic.jpa.exceptions.IllegalOrphanException;
import com.manojlovic.jpa.exceptions.NonexistentEntityException;
import com.manojlovic.jpa.exceptions.PreexistingEntityException;
import com.manojlovic.jpa.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class DepartmentsJpaController implements Serializable {

    public DepartmentsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Departments departments) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (departments.getDeptEmpCollection() == null) {
            departments.setDeptEmpCollection(new ArrayList<DeptEmp>());
        }
        if (departments.getDeptManagerCollection() == null) {
            departments.setDeptManagerCollection(new ArrayList<DeptManager>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<DeptEmp> attachedDeptEmpCollection = new ArrayList<DeptEmp>();
            for (DeptEmp deptEmpCollectionDeptEmpToAttach : departments.getDeptEmpCollection()) {
                deptEmpCollectionDeptEmpToAttach = em.getReference(deptEmpCollectionDeptEmpToAttach.getClass(), deptEmpCollectionDeptEmpToAttach.getDeptEmpPK());
                attachedDeptEmpCollection.add(deptEmpCollectionDeptEmpToAttach);
            }
            departments.setDeptEmpCollection(attachedDeptEmpCollection);
            Collection<DeptManager> attachedDeptManagerCollection = new ArrayList<DeptManager>();
            for (DeptManager deptManagerCollectionDeptManagerToAttach : departments.getDeptManagerCollection()) {
                deptManagerCollectionDeptManagerToAttach = em.getReference(deptManagerCollectionDeptManagerToAttach.getClass(), deptManagerCollectionDeptManagerToAttach.getDeptManagerPK());
                attachedDeptManagerCollection.add(deptManagerCollectionDeptManagerToAttach);
            }
            departments.setDeptManagerCollection(attachedDeptManagerCollection);
            em.persist(departments);
            for (DeptEmp deptEmpCollectionDeptEmp : departments.getDeptEmpCollection()) {
                Departments oldDepartmentsOfDeptEmpCollectionDeptEmp = deptEmpCollectionDeptEmp.getDepartments();
                deptEmpCollectionDeptEmp.setDepartments(departments);
                deptEmpCollectionDeptEmp = em.merge(deptEmpCollectionDeptEmp);
                if (oldDepartmentsOfDeptEmpCollectionDeptEmp != null) {
                    oldDepartmentsOfDeptEmpCollectionDeptEmp.getDeptEmpCollection().remove(deptEmpCollectionDeptEmp);
                    oldDepartmentsOfDeptEmpCollectionDeptEmp = em.merge(oldDepartmentsOfDeptEmpCollectionDeptEmp);
                }
            }
            for (DeptManager deptManagerCollectionDeptManager : departments.getDeptManagerCollection()) {
                Departments oldDepartmentsOfDeptManagerCollectionDeptManager = deptManagerCollectionDeptManager.getDepartments();
                deptManagerCollectionDeptManager.setDepartments(departments);
                deptManagerCollectionDeptManager = em.merge(deptManagerCollectionDeptManager);
                if (oldDepartmentsOfDeptManagerCollectionDeptManager != null) {
                    oldDepartmentsOfDeptManagerCollectionDeptManager.getDeptManagerCollection().remove(deptManagerCollectionDeptManager);
                    oldDepartmentsOfDeptManagerCollectionDeptManager = em.merge(oldDepartmentsOfDeptManagerCollectionDeptManager);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDepartments(departments.getDeptNo()) != null) {
                throw new PreexistingEntityException("Departments " + departments + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Departments departments) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Departments persistentDepartments = em.find(Departments.class, departments.getDeptNo());
            Collection<DeptEmp> deptEmpCollectionOld = persistentDepartments.getDeptEmpCollection();
            Collection<DeptEmp> deptEmpCollectionNew = departments.getDeptEmpCollection();
            Collection<DeptManager> deptManagerCollectionOld = persistentDepartments.getDeptManagerCollection();
            Collection<DeptManager> deptManagerCollectionNew = departments.getDeptManagerCollection();
            List<String> illegalOrphanMessages = null;
            for (DeptEmp deptEmpCollectionOldDeptEmp : deptEmpCollectionOld) {
                if (!deptEmpCollectionNew.contains(deptEmpCollectionOldDeptEmp)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptEmp " + deptEmpCollectionOldDeptEmp + " since its departments field is not nullable.");
                }
            }
            for (DeptManager deptManagerCollectionOldDeptManager : deptManagerCollectionOld) {
                if (!deptManagerCollectionNew.contains(deptManagerCollectionOldDeptManager)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain DeptManager " + deptManagerCollectionOldDeptManager + " since its departments field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<DeptEmp> attachedDeptEmpCollectionNew = new ArrayList<DeptEmp>();
            for (DeptEmp deptEmpCollectionNewDeptEmpToAttach : deptEmpCollectionNew) {
                deptEmpCollectionNewDeptEmpToAttach = em.getReference(deptEmpCollectionNewDeptEmpToAttach.getClass(), deptEmpCollectionNewDeptEmpToAttach.getDeptEmpPK());
                attachedDeptEmpCollectionNew.add(deptEmpCollectionNewDeptEmpToAttach);
            }
            deptEmpCollectionNew = attachedDeptEmpCollectionNew;
            departments.setDeptEmpCollection(deptEmpCollectionNew);
            Collection<DeptManager> attachedDeptManagerCollectionNew = new ArrayList<DeptManager>();
            for (DeptManager deptManagerCollectionNewDeptManagerToAttach : deptManagerCollectionNew) {
                deptManagerCollectionNewDeptManagerToAttach = em.getReference(deptManagerCollectionNewDeptManagerToAttach.getClass(), deptManagerCollectionNewDeptManagerToAttach.getDeptManagerPK());
                attachedDeptManagerCollectionNew.add(deptManagerCollectionNewDeptManagerToAttach);
            }
            deptManagerCollectionNew = attachedDeptManagerCollectionNew;
            departments.setDeptManagerCollection(deptManagerCollectionNew);
            departments = em.merge(departments);
            for (DeptEmp deptEmpCollectionNewDeptEmp : deptEmpCollectionNew) {
                if (!deptEmpCollectionOld.contains(deptEmpCollectionNewDeptEmp)) {
                    Departments oldDepartmentsOfDeptEmpCollectionNewDeptEmp = deptEmpCollectionNewDeptEmp.getDepartments();
                    deptEmpCollectionNewDeptEmp.setDepartments(departments);
                    deptEmpCollectionNewDeptEmp = em.merge(deptEmpCollectionNewDeptEmp);
                    if (oldDepartmentsOfDeptEmpCollectionNewDeptEmp != null && !oldDepartmentsOfDeptEmpCollectionNewDeptEmp.equals(departments)) {
                        oldDepartmentsOfDeptEmpCollectionNewDeptEmp.getDeptEmpCollection().remove(deptEmpCollectionNewDeptEmp);
                        oldDepartmentsOfDeptEmpCollectionNewDeptEmp = em.merge(oldDepartmentsOfDeptEmpCollectionNewDeptEmp);
                    }
                }
            }
            for (DeptManager deptManagerCollectionNewDeptManager : deptManagerCollectionNew) {
                if (!deptManagerCollectionOld.contains(deptManagerCollectionNewDeptManager)) {
                    Departments oldDepartmentsOfDeptManagerCollectionNewDeptManager = deptManagerCollectionNewDeptManager.getDepartments();
                    deptManagerCollectionNewDeptManager.setDepartments(departments);
                    deptManagerCollectionNewDeptManager = em.merge(deptManagerCollectionNewDeptManager);
                    if (oldDepartmentsOfDeptManagerCollectionNewDeptManager != null && !oldDepartmentsOfDeptManagerCollectionNewDeptManager.equals(departments)) {
                        oldDepartmentsOfDeptManagerCollectionNewDeptManager.getDeptManagerCollection().remove(deptManagerCollectionNewDeptManager);
                        oldDepartmentsOfDeptManagerCollectionNewDeptManager = em.merge(oldDepartmentsOfDeptManagerCollectionNewDeptManager);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = departments.getDeptNo();
                if (findDepartments(id) == null) {
                    throw new NonexistentEntityException("The departments with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Departments departments;
            try {
                departments = em.getReference(Departments.class, id);
                departments.getDeptNo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The departments with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<DeptEmp> deptEmpCollectionOrphanCheck = departments.getDeptEmpCollection();
            for (DeptEmp deptEmpCollectionOrphanCheckDeptEmp : deptEmpCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Departments (" + departments + ") cannot be destroyed since the DeptEmp " + deptEmpCollectionOrphanCheckDeptEmp + " in its deptEmpCollection field has a non-nullable departments field.");
            }
            Collection<DeptManager> deptManagerCollectionOrphanCheck = departments.getDeptManagerCollection();
            for (DeptManager deptManagerCollectionOrphanCheckDeptManager : deptManagerCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Departments (" + departments + ") cannot be destroyed since the DeptManager " + deptManagerCollectionOrphanCheckDeptManager + " in its deptManagerCollection field has a non-nullable departments field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(departments);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Departments> findDepartmentsEntities() {
        return findDepartmentsEntities(true, -1, -1);
    }

    public List<Departments> findDepartmentsEntities(int maxResults, int firstResult) {
        return findDepartmentsEntities(false, maxResults, firstResult);
    }

    private List<Departments> findDepartmentsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Departments.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Departments findDepartments(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Departments.class, id);
        } finally {
            em.close();
        }
    }

    public int getDepartmentsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Departments> rt = cq.from(Departments.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
