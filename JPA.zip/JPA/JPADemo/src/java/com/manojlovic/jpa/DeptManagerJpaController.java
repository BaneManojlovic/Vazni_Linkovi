/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.jpa;

import com.manojlovic.jpa.exceptions.NonexistentEntityException;
import com.manojlovic.jpa.exceptions.PreexistingEntityException;
import com.manojlovic.jpa.exceptions.RollbackFailureException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 *
 * @author manojlovic
 */
public class DeptManagerJpaController implements Serializable {

    public DeptManagerJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DeptManager deptManager) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (deptManager.getDeptManagerPK() == null) {
            deptManager.setDeptManagerPK(new DeptManagerPK());
        }
        deptManager.getDeptManagerPK().setEmpNo(deptManager.getEmployees().getEmpNo());
        deptManager.getDeptManagerPK().setDeptNo(deptManager.getDepartments().getDeptNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Employees employees = deptManager.getEmployees();
            if (employees != null) {
                employees = em.getReference(employees.getClass(), employees.getEmpNo());
                deptManager.setEmployees(employees);
            }
            Departments departments = deptManager.getDepartments();
            if (departments != null) {
                departments = em.getReference(departments.getClass(), departments.getDeptNo());
                deptManager.setDepartments(departments);
            }
            em.persist(deptManager);
            if (employees != null) {
                employees.getDeptManagerCollection().add(deptManager);
                employees = em.merge(employees);
            }
            if (departments != null) {
                departments.getDeptManagerCollection().add(deptManager);
                departments = em.merge(departments);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findDeptManager(deptManager.getDeptManagerPK()) != null) {
                throw new PreexistingEntityException("DeptManager " + deptManager + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DeptManager deptManager) throws NonexistentEntityException, RollbackFailureException, Exception {
        deptManager.getDeptManagerPK().setEmpNo(deptManager.getEmployees().getEmpNo());
        deptManager.getDeptManagerPK().setDeptNo(deptManager.getDepartments().getDeptNo());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptManager persistentDeptManager = em.find(DeptManager.class, deptManager.getDeptManagerPK());
            Employees employeesOld = persistentDeptManager.getEmployees();
            Employees employeesNew = deptManager.getEmployees();
            Departments departmentsOld = persistentDeptManager.getDepartments();
            Departments departmentsNew = deptManager.getDepartments();
            if (employeesNew != null) {
                employeesNew = em.getReference(employeesNew.getClass(), employeesNew.getEmpNo());
                deptManager.setEmployees(employeesNew);
            }
            if (departmentsNew != null) {
                departmentsNew = em.getReference(departmentsNew.getClass(), departmentsNew.getDeptNo());
                deptManager.setDepartments(departmentsNew);
            }
            deptManager = em.merge(deptManager);
            if (employeesOld != null && !employeesOld.equals(employeesNew)) {
                employeesOld.getDeptManagerCollection().remove(deptManager);
                employeesOld = em.merge(employeesOld);
            }
            if (employeesNew != null && !employeesNew.equals(employeesOld)) {
                employeesNew.getDeptManagerCollection().add(deptManager);
                employeesNew = em.merge(employeesNew);
            }
            if (departmentsOld != null && !departmentsOld.equals(departmentsNew)) {
                departmentsOld.getDeptManagerCollection().remove(deptManager);
                departmentsOld = em.merge(departmentsOld);
            }
            if (departmentsNew != null && !departmentsNew.equals(departmentsOld)) {
                departmentsNew.getDeptManagerCollection().add(deptManager);
                departmentsNew = em.merge(departmentsNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                DeptManagerPK id = deptManager.getDeptManagerPK();
                if (findDeptManager(id) == null) {
                    throw new NonexistentEntityException("The deptManager with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(DeptManagerPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            DeptManager deptManager;
            try {
                deptManager = em.getReference(DeptManager.class, id);
                deptManager.getDeptManagerPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The deptManager with id " + id + " no longer exists.", enfe);
            }
            Employees employees = deptManager.getEmployees();
            if (employees != null) {
                employees.getDeptManagerCollection().remove(deptManager);
                employees = em.merge(employees);
            }
            Departments departments = deptManager.getDepartments();
            if (departments != null) {
                departments.getDeptManagerCollection().remove(deptManager);
                departments = em.merge(departments);
            }
            em.remove(deptManager);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DeptManager> findDeptManagerEntities() {
        return findDeptManagerEntities(true, -1, -1);
    }

    public List<DeptManager> findDeptManagerEntities(int maxResults, int firstResult) {
        return findDeptManagerEntities(false, maxResults, firstResult);
    }

    private List<DeptManager> findDeptManagerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DeptManager.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DeptManager findDeptManager(DeptManagerPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DeptManager.class, id);
        } finally {
            em.close();
        }
    }

    public int getDeptManagerCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DeptManager> rt = cq.from(DeptManager.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
